# WSQ ParaBank Real-Site Release Pack

This project complements the SauceDemo pack with registration, cookie/session, query-param, and recovery scenarios on a second real site.

## Recommended run order
1. 01-happy-register-openaccount-billpay.yaml
2. 02-happy-cookie-query-session.yaml
3. 11-feature-condition-false-and-recovery.yaml

## Notes
- Dynamic usernames/SSNs are generated at runtime using built-in tokens such as `${nowEpochMs}` and `${random6}`.
- These suites are useful for validating non-UI storage/cookie actions and condition recovery paths against a live banking demo site.
