# WSQ ParaBank Real-Site Learning Path

Recommended order:

1. `01-dynamic-registration-login-cookie.yaml` - dynamic registration and login
2. `06-feature-cookie-query-session.yaml` - cookie capture, URL params, session storage
3. `04-condition-and-multi-assert-focus.yaml` - multi-assert branching
4. `07-feature-condition-false-and-recovery.yaml` - false condition and graceful recovery
5. `02-open-account-transfer-loan.yaml` - open account, transfer, loan
6. `03-billpay-nonui-query-cookie.yaml` - bill pay and non-UI capture
7. `05-happy-register-open-transfer-billpay.yaml` - broad happy-path reference

All suites keep a 1-second wait so users can follow the flow visually.
