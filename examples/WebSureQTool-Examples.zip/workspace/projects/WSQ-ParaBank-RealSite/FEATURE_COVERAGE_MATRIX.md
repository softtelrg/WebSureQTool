# ParaBank Feature Coverage Matrix

| Feature | Primary suite | Secondary reference |
|---|---|---|
| Happy flow | `01-happy-register-openaccount-billpay.yaml` | `03-billpay-nonui-query-cookie.yaml` |
| Query parameter capture | `02-happy-cookie-query-session.yaml` | `06-feature-cookie-query-runtime.yaml` |
| Cookie capture | `01-happy-register-openaccount-billpay.yaml` | `03-billpay-nonui-query-cookie.yaml` |
| Session storage capture | `02-happy-cookie-query-session.yaml` | `03-billpay-nonui-query-cookie.yaml` |
| Multi-assertion | `04-condition-and-multi-assert-focus.yaml` | — |
| Branch / conditions | `04-condition-and-multi-assert-focus.yaml` | `07-feature-condition-false-and-recovery.yaml` |
| False branch / recovery | `07-feature-condition-false-and-recovery.yaml` | `11-feature-condition-false-and-recovery.yaml` |
| Wait-only | `08-feature-wait-only-parabank.yaml` | — |
| Store / reuse | `09-feature-store-reuse-parabank.yaml` | `04-condition-and-multi-assert-focus.yaml` |
