# WSQ SauceDemo Real-Site Learning Path

Recommended order for a new WebSureQTool user:

1. `01-login-sort-cart-badge.yaml` - basic login, select, cart badge
2. `02-checkout-e2e.yaml` - straightforward happy checkout
3. `07-single-regex-step-smoke.yaml` - standalone regex assertion
4. `11-feature-data-validation.yaml` - null / int / numeric style checks
5. `12-feature-single-assertions.yaml` - single assertions
6. `13-feature-multi-assertions.yaml` - assertion groups and boolean logic
7. `14-feature-wait-only.yaml` - explicit waits only
8. `15-feature-url-storage-capture.yaml` - capture/store URL, title, storage
9. `16-feature-conditions-negative-handling.yaml` - false path, true path, onErrorGoto
10. `17-feature-loop-retry.yaml` - bounded loop and retry
11. `18-feature-duplicate-multiple-same-step.yaml` - repeated/same step patterns
12. `08-session-login-only.yaml` then `09-session-continue-after-login.yaml` - dependency on previous suite / session chain
13. `06-complete-capability-demonstration.yaml` - broad golden capability suite
14. `10-happy-full-cart-checkout.yaml` - comprehensive happy-path reference

Each suite uses 1-second waits so the flow is visible during demos.
