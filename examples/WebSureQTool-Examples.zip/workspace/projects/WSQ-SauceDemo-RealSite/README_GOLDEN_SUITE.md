Golden suite reliability notes

1. Close the suite tab if it is already open.
2. Replace the project folder, then reopen the suite from Project Explorer.
3. Clear any previously picked steps before running.
4. For the first validation, run from Run Panel so the saved YAML is the source of truth.
5. The golden suite now uses data/golden.csv to avoid shared-key collisions with other demo suites.
6. The duplicate/repeat suite now uses data/duplicate.csv.

If a log still shows:
- Products assertion expecting Checkout: Overview, or
- click #add-to-cart-sauce-labs-bolt-t-shirt,
then you are still executing an older in-memory suite snapshot, not the corrected files.
