# WSQ SauceDemo Feature Coverage Matrix

Use these suites as the primary reference set for the web module.

## Complex happy suites
- `06-complete-capability-demonstration.yaml` — broad end-to-end capability coverage in one suite
- `10-happy-full-checkout.yaml` — clean happy-path checkout
- `08-session-login-only.yaml` + `09-session-continue-after-login.yaml` — previous-suite dependency / reused browser session

## Focused feature suites
- `11-feature-data-validation.yaml` — numeric/data-type/null validation
- `12-feature-regex-standalone.yaml` — standalone regex assertion
- `13-feature-single-assert.yaml` — single assertion only
- `14-feature-multi-assert.yaml` — grouped assertions with mixed logic
- `15-feature-same-step-multiple-times.yaml` — same action/selector reused multiple times
- `16-feature-wait-only.yaml` — explicit waits by themselves
- `17-feature-url-and-session-capture.yaml` — capture URL, query param, session storage
- `18-feature-conditions-false-negative.yaml` — false branch + negative/recovery path
- `19-feature-loop-retry-store.yaml` — loop + retry + store captures
- `20-feature-store-reuse.yaml` — capture/store/runtime-variable reuse

## Recommended run order for a new user
1. `10-happy-full-checkout.yaml`
2. `11-feature-data-validation.yaml`
3. `12-feature-regex-standalone.yaml`
4. `13-feature-single-assert.yaml`
5. `14-feature-multi-assert.yaml`
6. `15-feature-same-step-multiple-times.yaml`
7. `16-feature-wait-only.yaml`
8. `17-feature-url-and-session-capture.yaml`
9. `18-feature-conditions-false-negative.yaml`
10. `19-feature-loop-retry-store.yaml`
11. `20-feature-store-reuse.yaml`
12. `08-session-login-only.yaml`
13. `09-session-continue-after-login.yaml`
14. `06-complete-capability-demonstration.yaml`
