# Session Chain Suites

Run these sequentially from **Run Panel**:
1. 08-session-login-only.yaml
2. 09-session-continue-after-login.yaml

Suite 08 preserves the managed browser session using key `saucedemo-sso`.
Suite 09 reuses that same session and starts from the current page without injecting a fresh navigate step.
