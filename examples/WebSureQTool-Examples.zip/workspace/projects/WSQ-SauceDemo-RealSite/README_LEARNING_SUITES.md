# WSQ SauceDemo Learning Suites

## Start here
If you are new to WebSureQTool, run these in order:

1. `10-happy-full-checkout.yaml`
2. `11-feature-data-validation.yaml`
3. `12-feature-regex-standalone.yaml`
4. `13-feature-single-assert.yaml`
5. `14-feature-multi-assert.yaml`
6. `15-feature-same-step-multiple-times.yaml`
7. `16-feature-wait-only.yaml`
8. `17-feature-url-and-session-capture.yaml`
9. `18-feature-conditions-false-negative.yaml`
10. `19-feature-loop-retry-store.yaml`
11. `20-feature-store-reuse.yaml`
12. `08-session-login-only.yaml`
13. `09-session-continue-after-login.yaml`
14. `06-complete-capability-demonstration.yaml`

## What each suite teaches
- `10-happy-full-checkout.yaml` — clean happy-path checkout
- `11-feature-data-validation.yaml` — integer/numeric/null/range validation
- `12-feature-regex-standalone.yaml` — regex validation as a single explicit step
- `13-feature-single-assert.yaml` — simplest single assertion example
- `14-feature-multi-assert.yaml` — multi-assert group with mixed logic
- `15-feature-same-step-multiple-times.yaml` — same selector/action repeated multiple times
- `16-feature-wait-only.yaml` — explicit waits with no other advanced features mixed in
- `17-feature-url-and-session-capture.yaml` — capture from URL query param and session storage
- `18-feature-conditions-false-negative.yaml` — false branch plus negative-path recovery
- `19-feature-loop-retry-store.yaml` — loop, retry, and capture/store together
- `20-feature-store-reuse.yaml` — runtime store + reuse of captured values
- `08-session-login-only.yaml` + `09-session-continue-after-login.yaml` — dependency on previous suite / reused browser session
- `06-complete-capability-demonstration.yaml` — broad end-to-end reference suite

Every step uses a default 1-second wait so the flow is visible during demos.
