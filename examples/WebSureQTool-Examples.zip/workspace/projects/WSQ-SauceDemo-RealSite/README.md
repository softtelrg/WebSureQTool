# WSQ SauceDemo Real-Site Release Pack

This project is a curated set of SauceDemo suites intended to teach and validate the main WebSureQTool web-module capabilities.

## Recommended run order
1. 01-happy-login-cart-checkout.yaml
2. 02-golden-capability-demonstration.yaml
3. 03-session-login-only.yaml
4. 04-session-continue-after-login.yaml
5. 11-20 feature suites as needed

## Notes
- Every authored step uses a default 1 second wait where practical so execution is visible.
- Suites 03 and 04 are the session-chain pair. Run 03 first, then 04 in the same batch to validate reuse of the managed browser session.
- Suite 17 demonstrates URL/query/session capture.
- Suite 19 demonstrates loop + retry + store.
