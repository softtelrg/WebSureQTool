# Real-Site Reference Guide

This pack intentionally replaces the earlier generic samples with **two focused real-site web projects**:

- `workspace/projects/WSQ-SauceDemo-RealSite`
- `workspace/projects/WSQ-ParaBank-RealSite`

and one **real API reference project**:

- `workspace/api-projects/WSQ-RealApi-Reference`

## Recommended validation order

### SauceDemo
1. `01-login-sort-cart-badge.yaml`
2. `02-checkout-e2e.yaml`
3. `03-runtime-capture-nonui-conditions.yaml`
4. `04-negative-login-regex.yaml`
5. `05-duplicate-friendly-repeatable-blocks.yaml`

### ParaBank
1. `01-dynamic-registration-login-cookie.yaml`
2. `02-open-account-transfer-loan.yaml`
3. `03-billpay-nonui-query-cookie.yaml`
4. `04-condition-and-multi-assert-focus.yaml`

### API
1. `01-dummyjson-login-and-search.json`
2. `02-dummyjson-auth-me-manual-token.json` (after copying token)
3. `03-parabank-public-rest.json`

## Design rules used in this pack
- Every authored step uses `waitMs: 1000` unless the row is a label-only marker.
- All web suites use `datasetRef` so code generation and execution consume current dataset files.
- ParaBank suites generate usernames at runtime to avoid hard-coded test-user collisions.
- The suites include examples for repeated steps, multi-assertions, regex, numeric checks, conditions, runtime capture, URL param checks, cookies, and capture JS.


Compatibility note: v3 adds page.url/baseUrl and normalizes css -> selector so Suite Editor can open and display the suites correctly.
