# API Feature Coverage Matrix

| Feature | Primary suite | Secondary reference |
|---|---|---|
| Direct GET | `01-direct-get-with-headers.json` | — |
| Direct POST JSON body | `02-post-json-body.json` | `03-post-json-plus-query.json` |
| Query parameters | `01-direct-get-with-headers.json` | `03-post-json-plus-query.json` |
| Custom headers | `01-direct-get-with-headers.json` | `03-post-json-plus-query.json` |
| Token login | `04-token-login.json` | — |
| Authenticated follow-up request | `05-manual-token-authenticated-get.json` | — |
| Spec-driven execution | `06-load-from-spec-petstore.json` | — |
| Secondary real API example | `07-direct-parabank-login.json` | — |
