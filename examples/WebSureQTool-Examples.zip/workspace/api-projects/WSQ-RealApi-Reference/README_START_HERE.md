# WSQ Real API Reference - Start Here

This project is the API learning pack.

## Recommended run order

1. `01-direct-get-with-headers.json`
2. `02-post-json-body.json`
3. `03-post-json-plus-query.json`
4. `04-token-login.json`
5. `05-manual-token-authenticated-get.json`
6. `06-load-from-spec-petstore.json`
7. `07-direct-parabank-login.json`

## What each suite is for

- `01-direct-get-with-headers.json` – direct GET, suite headers, query params
- `02-post-json-body.json` – direct POST with JSON body
- `03-post-json-plus-query.json` – POST body plus query parameters together
- `04-token-login.json` – obtain an access token from a real login endpoint
- `05-manual-token-authenticated-get.json` – use the token from suite 04 in a follow-up request
- `06-load-from-spec-petstore.json` – spec-driven execution from an OpenAPI URL
- `07-direct-parabank-login.json` – direct request against another real API surface

## Manual token note

The current API sample pack keeps token handoff explicit for learning clarity.
Run suite 04, copy the returned token, paste it into suite 05 as `Bearer <token>`, then run suite 05.
