# WebSureQTool Release Reference Guide

This workspace contains three curated reference projects:

- `projects/WSQ-SauceDemo-RealSite`
- `projects/WSQ-ParaBank-RealSite`
- `api-projects/WSQ-RealApi-Reference`

## Web smoke path
1. SauceDemo `01-happy-login-cart-checkout.yaml`
2. SauceDemo `02-golden-capability-demonstration.yaml`
3. SauceDemo session-chain pair `03-session-login-only.yaml` then `04-session-continue-after-login.yaml`
4. ParaBank `01-happy-register-openaccount-billpay.yaml`
5. ParaBank `02-happy-cookie-query-session.yaml`

## Focused feature suites
### SauceDemo
- `11-feature-data-validation.yaml`
- `12-feature-regex-standalone.yaml`
- `13-feature-single-assert.yaml`
- `14-feature-multi-assert.yaml`
- `15-feature-same-step-multiple-times.yaml`
- `16-feature-wait-only.yaml`
- `17-feature-url-and-session-capture.yaml`
- `18-feature-conditions-false-negative.yaml`
- `19-feature-loop-retry-store.yaml`
- `20-feature-store-reuse.yaml`

### ParaBank
- `11-feature-condition-false-and-recovery.yaml`

## API learning path
1. `01-direct-get-with-headers.json`
2. `02-post-json-body.json`
3. `03-post-json-plus-query.json`
4. `04-token-login.json`
5. `05-manual-token-authenticated-get.json`
6. `06-load-from-spec-petstore.json`
7. `07-direct-parabank-login.json`

## Notes
- All web suites are file-backed (`datasetRef`) and use 1 second waits where practical.
- The SauceDemo session-chain pair is the primary proof for managed-session reuse.
- The API token follow-up suite intentionally requires a token captured from the prior login suite; this is documented in the API project README.
