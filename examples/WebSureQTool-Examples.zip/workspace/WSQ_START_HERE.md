# WebSureQTool Sample Workspace - Start Here

This workspace is intentionally centered on two real web sites and one real API reference project:

## Web Projects
1. `WSQ-SauceDemo-RealSite`
   - best for login, cart, checkout, loops, retry, regex, data validation, capture/store, conditions, session-chain reuse

2. `WSQ-ParaBank-RealSite`
   - best for registration, cookies, query params, account flows, bill pay, branch handling

## API Project
3. `WSQ-RealApi-Reference`
   - direct HTTP examples (httpbin)
   - JSON body login/token examples (DummyJSON)
   - spec-driven examples (ParaBank OpenAPI)

### Suggested learning path
- SauceDemo README_START_HERE.md
- ParaBank README_START_HERE.md
- API README_START_HERE.md

### Suite-to-suite session reuse
Use SauceDemo suites:
- `08-session-login-only.yaml`
- `09-session-continue-after-login.yaml`

### Golden capability suite
Use SauceDemo suite:
- `06-complete-capability-demonstration.yaml`

### Feature-focused suites
Use the SauceDemo 11-18 range and ParaBank 06-07 range to validate specific capabilities in isolation.
