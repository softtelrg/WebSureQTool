# WebSureQTool Release Smoke Guide

## Web projects
### SauceDemo
- 10-happy-full-checkout.yaml
- 08-session-login-only.yaml
- 09-session-continue-after-login.yaml
- 11-feature-data-validation.yaml
- 12-feature-regex-standalone.yaml
- 13-feature-single-assert.yaml
- 14-feature-multi-assert.yaml
- 15-feature-same-step-multiple-times.yaml
- 16-feature-wait-only.yaml
- 17-feature-url-and-session-capture.yaml
- 18-feature-conditions-false-negative.yaml
- 19-feature-loop-retry-store.yaml

### ParaBank
- 05-happy-register-openaccount-billpay.yaml
- 01-dynamic-registration-login-cookie.yaml
- 02-open-account-transfer-loan.yaml
- 03-billpay-nonui-query-cookie.yaml
- 04-condition-and-multi-assert-focus.yaml
- 06-feature-cookie-query-runtime.yaml

## API project
### WSQ-RealApi-Reference
- 01-direct-dummyjson-login-body-header.json
- 02-direct-dummyjson-search-params.json
- 03-direct-dummyjson-token-auth.json
- 04-direct-dummyjson-body-and-params.json
- 05-spec-dummyjson-login-and-search.json
- 06-spec-parabank-safe-smoke.json

## Session chain check
1. Run 08-session-login-only.yaml from Run Panel.
2. Immediately run 09-session-continue-after-login.yaml from Run Panel.
3. Suite 09 should continue from the inventory page and complete checkout in the reused browser session.

## History / artifacts
Each web run should produce:
- report.html
- run.json
- log.txt or derived run.log
- executed-suite.yaml
- screens/suite-pass.png or suite-fail.png
